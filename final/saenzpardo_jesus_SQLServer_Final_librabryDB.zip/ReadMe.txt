My video was cut short because of the 5 minute time limit on my free trial!  

Let me know if there's any questions and I appreciate any feedback.

Thanks for the great class.